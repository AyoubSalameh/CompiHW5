#ifndef COMPIHW5_DEFS_H
#define COMPIHW5_DEFS_H

class Node;
class Statements;
class Statement;
class Type;
class Call;
class Exp;
class ExpList;
class Statement;
class Statements;
class Program;
class Funcs;
class OverRide;
class RetType;
class FormalDecl;
class FormalsList;
class Formals;
class FuncDecl;
class MarkerM;

class CodeComposer;


#endif //COMPIHW5_DEFS_H